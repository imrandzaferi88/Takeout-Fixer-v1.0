package com.takeout.fixer

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private var inputUri: Uri? = null
    private lateinit var btnSelectInput: Button
    private lateinit var btnStart: Button
    private lateinit var tvInputPath: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var progressBar: ProgressBar

    private val pickInputLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            inputUri = uri
            tvInputPath.text = "Input URI: $uri"
            btnStart.isEnabled = true
            log("File ZIP selezionato.")
        }
    }

    private val createOutputLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { outUri ->
        val inUri = inputUri
        if (inUri != null && outUri != null) {
            processZip(inUri, outUri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnSelectInput = findViewById(R.id.btnSelectInput)
        btnStart = findViewById(R.id.btnStart)
        tvInputPath = findViewById(R.id.tvInputPath)
        tvStatus = findViewById(R.id.tvStatus)
        tvLog = findViewById(R.id.tvLog)
        progressBar = findViewById(R.id.progressBar)

        btnSelectInput.setOnClickListener {
            pickInputLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*"))
        }

        btnStart.setOnClickListener {
            createOutputLauncher.launch("Takeout_FIXED.zip")
        }
    }

    private fun log(msg: String) {
        runOnUiThread {
            tvLog.append("$msg\n")
        }
    }

    private fun updateProgress(pct: Int, status: String) {
        runOnUiThread {
            progressBar.progress = pct
            tvStatus.text = status
        }
    }

    private fun findJsonForMedia(mediaFile: File): File? {
        val parent = mediaFile.parentFile ?: return null
        val name = mediaFile.name
        val stem = mediaFile.nameWithoutExtension
        val ext = mediaFile.extension

        val children = parent.listFiles() ?: return null
        for (f in children) {
            if (f.name.startsWith("$name.") && f.name.endsWith(".json")) {
                return f
            }
        }
        val direct = File(parent, "$stem.json")
        if (direct.exists()) return direct

        if (stem.contains("(") && stem.endsWith(")")) {
            val idx = stem.lastIndexOf("(")
            val base = stem.substring(0, idx)
            val num = stem.substring(idx)
            val swapped = File(parent, "$base.$ext$num.json")
            if (swapped.exists()) return swapped
        }
        return null
    }

    private fun convertToRationalLatLon(deg: Double): String {
        val d = abs(deg)
        val degrees = d.toInt()
        val minutesFloat = (d - degrees) * 60
        val minutes = minutesFloat.toInt()
        val seconds = ((minutesFloat - minutes) * 60 * 10000).toInt()
        return "$degrees/1,$minutes/1,$seconds/10000"
    }

    private fun processZip(inUri: Uri, outUri: Uri) {
        btnSelectInput.isEnabled = false
        btnStart.isEnabled = false

        lifecycleScope.launch(Dispatchers.IO) {
            val workDir = File(cacheDir, "takeout_work_${System.currentTimeMillis()}")
            workDir.mkdirs()

            try {
                updateProgress(5, "1/3 Estrazione ZIP su memoria interna...")
                log("Estrazione file in corso...")

                contentResolver.openInputStream(inUri)?.use { rawIn ->
                    ZipInputStream(BufferedInputStream(rawIn)).use { zis ->
                        var entry: ZipEntry? = zis.nextEntry
                        val buffer = ByteArray(65536)
                        while (entry != null) {
                            if (!entry.isDirectory) {
                                val outFile = File(workDir, entry.name)
                                outFile.parentFile?.mkdirs()
                                FileOutputStream(outFile).use { fos ->
                                    var len: Int
                                    while (zis.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                }
                            }
                            zis.closeEntry()
                            entry = zis.nextEntry
                        }
                    }
                }

                updateProgress(35, "2/3 Scansione e unione metadati...")
                val allFiles = workDir.walkTopDown().filter { it.isFile && !it.name.endsWith(".json", true) }.toList()
                val total = allFiles.size
                var merged = 0

                val exifDateFormat = SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).apply {
                    timeZone = TimeZone.getDefault()
                }

                for ((index, mediaFile) in allFiles.withIndex()) {
                    val jsonFile = findJsonForMedia(mediaFile)
                    if (jsonFile != null && jsonFile.exists()) {
                        try {
                            val jsonObj = JSONObject(jsonFile.readText())
                            val ts = jsonObj.optJSONObject("photoTakenTime")?.optString("timestamp", "0")?.toLongOrNull() ?: 0L
                            val geo = jsonObj.optJSONObject("geoData")
                            val lat = geo?.optDouble("latitude", 0.0) ?: 0.0
                            val lon = geo?.optDouble("longitude", 0.0) ?: 0.0
                            val desc = jsonObj.optString("description", "")

                            val ext = mediaFile.extension.lowercase()
                            if (ext == "jpg" || ext == "jpeg" || ext == "webp") {
                                val exif = ExifInterface(mediaFile)
                                if (ts > 0) {
                                    val dateStr = exifDateFormat.format(Date(ts * 1000))
                                    exif.setAttribute(ExifInterface.TAG_DATETIME, dateStr)
                                    exif.setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, dateStr)
                                    exif.setAttribute(ExifInterface.TAG_DATETIME_DIGITIZED, dateStr)
                                }
                                if (lat != 0.0 || lon != 0.0) {
                                    exif.setAttribute(ExifInterface.TAG_GPS_LATITUDE, convertToRationalLatLon(lat))
                                    exif.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF, if (lat >= 0) "N" else "S")
                                    exif.setAttribute(ExifInterface.TAG_GPS_LONGITUDE, convertToRationalLatLon(lon))
                                    exif.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF, if (lon >= 0) "E" else "W")
                                }
                                if (desc.isNotEmpty()) {
                                    exif.setAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION, desc)
                                }
                                exif.saveAttributes()
                            }

                            if (ts > 0) {
                                mediaFile.setLastModified(ts * 1000)
                            }
                            merged++
                        } catch (e: Exception) {
                            log("Ignorato JSON per ${mediaFile.name}: ${e.message}")
                        }
                    }

                    if (index % 15 == 0 || index == total - 1) {
                        val pct = 35 + ((index + 1) * 35 / total.coerceAtLeast(1))
                        updateProgress(pct, "2/3 Unione metadati: ${index + 1}/$total")
                    }
                }

                updateProgress(70, "3/3 Creazione nuovo file ZIP...")
                log("Compressione di $total file multimediali ($merged uniti con JSON)...")

                contentResolver.openOutputStream(outUri)?.use { rawOut ->
                    ZipOutputStream(BufferedOutputStream(rawOut)).use { zos ->
                        val buffer = ByteArray(65536)
                        for ((index, mediaFile) in allFiles.withIndex()) {
                            val relPath = mediaFile.relativeTo(workDir).path.replace("\\", "/")
                            val zipEntry = ZipEntry(relPath).apply {
                                time = mediaFile.lastModified()
                            }
                            zos.putNextEntry(zipEntry)
                            FileInputStream(mediaFile).use { fis ->
                                var len: Int
                                while (fis.read(buffer).also { len = it } > 0) {
                                    zos.write(buffer, 0, len)
                                }
                            }
                            zos.closeEntry()

                            if (index % 20 == 0 || index == total - 1) {
                                val pct = 70 + ((index + 1) * 30 / total.coerceAtLeast(1))
                                updateProgress(pct, "3/3 Scrittura ZIP: ${index + 1}/$total")
                            }
                        }
                    }
                }

                updateProgress(100, "Completato! ($merged/$total uniti)")
                log("Operazione conclusa con successo! File salvato.")

            } catch (e: Exception) {
                updateProgress(0, "Errore durante l'elaborazione")
                log("ERRORE: ${e.message}")
            } finally {
                workDir.deleteRecursively()
                withContext(Dispatchers.Main) {
                    btnSelectInput.isEnabled = true
                    btnStart.isEnabled = true
                }
            }
        }
    }
}
